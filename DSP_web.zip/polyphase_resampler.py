"""Kaiser-FIR anti-alias/anti-image stages + Farrow (cubic Lagrange) variable-ratio decimator.
All filters are embedded in a fixed-length N-tap array (zero padded, centred) so group delay is
constant when the controller changes taps/beta -> no phase jump. Filter changes are cross-faded."""
import numpy as np
from scipy.signal import firwin

FS = 48000
N = 127  # fixed filter length -> constant delay (N-1)/2 samples @48k


def design(fs_target, taps, beta):
    """Kaiser low-pass, effective length `taps` (odd), embedded in N taps. Tier 48k -> pure delay."""
    h = np.zeros(N)
    c = (N - 1) // 2
    if fs_target >= FS:
        h[c] = 1.0
        return h
    taps |= 1
    k = firwin(taps, 0.9 * fs_target / 2, window=("kaiser", beta), fs=FS)
    s = (N - taps) // 2
    h[s:s + taps] = k
    return h


class FIRStage:
    """Stateful FIR with history; on coefficient change cross-fades old->new across the frame."""
    def __init__(self):
        self.hist = np.zeros(N - 1)
        self.h = design(FS, 1, 0)

    def process(self, x, h_new):
        xe = np.concatenate([self.hist, x])
        y = np.convolve(xe, h_new, "valid")
        if not np.array_equal(h_new, self.h):
            yo = np.convolve(xe, self.h, "valid")
            w = np.linspace(0, 1, len(x), endpoint=False)
            y = (1 - w) * yo + w * y
            self.h = h_new
        self.hist = xe[-(N - 1):]
        return y


class Farrow:
    """Cubic-Lagrange Farrow interpolator; arbitrary, per-call-changeable step with continuous phase."""
    def __init__(self):
        self.buf = np.zeros(3); self.base = -3; self.pos = 0.0

    def process(self, x, step):
        self.buf = np.concatenate([self.buf, x])
        last = self.base + len(self.buf) - 1
        K = max(0, int(np.ceil((last - 1 - self.pos) / step)))
        p = self.pos + step * np.arange(K)
        p = p[p < last - 1]
        fl = np.floor(p); mu = p - fl; i = (fl - self.base).astype(int)
        y0, y1, y2, y3 = (self.buf[i - 1], self.buf[i], self.buf[i + 1], self.buf[i + 2])
        v0 = y1
        v1 = -y0 / 3 - y1 / 2 + y2 - y3 / 6
        v2 = y0 / 2 - y1 + y2 / 2
        v3 = -y0 / 6 + y1 / 2 - y2 / 2 + y3 / 6
        out = ((v3 * mu + v2) * mu + v1) * mu + v0
        self.pos = self.pos + step * len(p)
        keep = int(np.floor(self.pos)) - 1 - self.base
        self.buf = self.buf[keep:]; self.base += keep
        return out


class AdaptiveResampler:
    """encode(): 48k frame -> tier-rate samples.  decode(): tier-rate samples -> 48k frame."""
    def __init__(self):
        self.tx_fir, self.farrow, self.rx_fir = FIRStage(), Farrow(), FIRStage()

    def encode(self, frame, tier, taps, beta):
        y = self.tx_fir.process(frame, design(tier, taps, beta))
        return self.farrow.process(y, FS / tier)

    def decode(self, s, tier, taps, beta):
        L = FS // tier
        up = np.zeros(len(s) * L); up[::L] = s * L
        return self.rx_fir.process(up, design(tier, taps, beta))


class NaiveResampler:
    """Baseline: no anti-alias filter, pick-every-Lth decimation, zero-order-hold upsampling."""
    def encode(self, frame, tier, taps, beta):
        return frame[::FS // tier]

    def decode(self, s, tier, taps, beta):
        return np.repeat(s, FS // tier)
