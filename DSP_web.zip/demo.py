"""Synthetic speech + network traces -> 4 systems -> SNR / PESQ / transition-artifact / CPU metrics."""
import time, numpy as np
from scipy.signal import firwin, filtfilt, correlate
from polyphase_resampler import AdaptiveResampler, NaiveResampler, FS
from network_sim import simulate, lost, TIERS
from adaptive_controller import Controller

FR = FS * 20 // 1000  # 960 samples


def synth_speech(sec, seed=1):
    rng = np.random.default_rng(seed); n = int(sec * FS); out = np.zeros(n); i = 0
    while i < n:
        L = int(rng.uniform(.06, .15) * FS); t = np.arange(L) / FS; w = np.hanning(L)
        if rng.random() < .65:  # voiced: 3 formants, pitch-modulated, f0 90-220
            f0 = rng.uniform(90, 220) * (1 + .08 * np.sin(2 * np.pi * 5 * t))
            ph = 2 * np.pi * np.cumsum(f0) / FS
            F = [rng.uniform(400, 800), rng.uniform(1000, 2000), rng.uniform(2400, 3200)]
            seg = sum(np.exp(-.5 * ((h * f0 - fc) / 250) ** 2) * (1 / h) * np.sin(h * ph)
                      for h in range(1, 40) for fc in F)
            seg = seg / (np.abs(seg).max() + 1e-9)
        else:                   # unvoiced fricative: 3.5-9.5k tones + noise
            seg = sum(np.sin(2 * np.pi * rng.uniform(3500, 9500) * t + rng.uniform(0, 6)) for _ in range(4))
            seg = .25 * seg / 4 + .1 * np.diff(rng.normal(size=L + 1))
        e = min(L, n - i); out[i:i + e] += (seg * w)[:e]; i += max(1, e // 2)  # overlap-add
    return out / np.abs(out).max() * .8


def snr(ref, x): return 10 * np.log10((ref ** 2).sum() / (((ref - x) ** 2).sum() + 1e-12))


def run(x, net, mode, ctrl=None):
    """mode: 'adaptive' | 'naive_adaptive' | ('static', tier)"""
    rs = NaiveResampler() if mode == "naive_adaptive" else AdaptiveResampler()
    out, tiers, lostm, macs, t0 = [], [], [], 0, time.perf_counter()
    for k in range(len(net["bw"])):
        f = x[k * FR:(k + 1) * FR]
        if len(f) < FR: break
        if isinstance(mode, tuple): tier, taps, beta = mode[1], 63, 7.0
        else: tier, taps, beta = ctrl.decide(net["bw"][k], net["jitter"][k], net["cpu"][k])
        s = rs.encode(f, tier, taps, beta)
        lo = lost(net["bw"][k], net["jitter"][k], tier)
        if lo: s = np.zeros_like(s)                    # packet lost -> silence concealment
        out.append(rs.decode(s, tier, taps, beta)); tiers.append(tier); lostm.append(lo)
        if tier < FS and not isinstance(rs, NaiveResampler): macs += 2 * taps * tier * .02
    ms = (time.perf_counter() - t0) / len(tiers) * 1000
    return np.concatenate(out), np.array(tiers), np.array(lostm), macs / (len(tiers) * .02), ms


def evaluate(x, y, tiers, lostm):
    n = min(len(x), len(y))
    c = correlate(x[:FS * 2], y[:FS * 2], mode="full", method="fft")
    lags = np.arange(-len(y[:FS * 2]) + 1, len(x[:FS * 2]))
    m = (np.abs(lags) < 300); lag = int(lags[m][c[m].argmax()])   # y delayed by -lag
    d = -lag; yy = y[d:n]; yy = yy[:len(yy) // FR * FR]; xx = x[:len(yy)]
    lp = firwin(255, 3400, fs=FS); xb, yb = filtfilt(lp, 1, xx), filtfilt(lp, 1, yy)
    nf = len(yy) // FR; ok = np.repeat(~lostm[:nf], FR)
    e2 = (xb - yb) ** 2
    sw = [k for k in range(1, nf) if tiers[k] != tiers[k - 1] and not lostm[k] and not lostm[k - 1]]
    tr = np.zeros(len(yy), bool)
    for k in sw: tr[max(0, k * FR - 240):k * FR + 240] = True
    base = e2[ok & ~tr].mean() if (ok & ~tr).any() else np.nan
    ratio = e2[ok & tr].mean() / base if tr.any() and (ok & tr).any() else np.nan
    res = dict(snr_full=snr(xx, yy), snr_inband=snr(xb, yb),
               snr_rx_inband=snr(xb[ok], yb[ok]) if ok.any() else np.nan,
               loss=100 * lostm.mean(), switches=int((np.diff(tiers) != 0).sum()),
               trans_ratio=ratio, lag=d)
    try:
        from pesq import pesq
        from scipy.signal import resample_poly
        res["pesq"] = pesq(16000, resample_poly(xx, 1, 3), resample_poly(yy, 1, 3), "wb")
    except Exception:
        res["pesq"] = float("nan")
    return res


if __name__ == "__main__":
    SEC = 20
    x = synth_speech(SEC); net = simulate(SEC)
    ctrl = Controller(); print(f"Controller trained: oracle agreement {ctrl.train() * 100:.1f}%")
    systems = {"Adaptive (Kaiser+Farrow)": "adaptive", "Adaptive, naive resampler": "naive_adaptive",
               "Static 16 kHz": ("static", 16000), "Static 48 kHz": ("static", 48000)}
    rows, hist = {}, {}
    for name, mode in systems.items():
        c = Controller(); c.W1, c.b1, c.W2, c.b2 = ctrl.W1, ctrl.b1, ctrl.W2, ctrl.b2
        y, tiers, lm, macs, ms = run(x, net, mode if not isinstance(mode, str) or mode != "naive_adaptive" else mode, c)
        r = evaluate(x, y, tiers, lm); r.update(mmacs=macs / 1e6, ms_frame=ms); rows[name] = r; hist[name] = tiers
    print(f"\n{'System':28s} {'SNRfull':>8s} {'SNR<3.4k':>9s} {'SNR<3.4k rx':>11s} {'Loss%':>6s} {'Sw':>4s} "
          f"{'TransErr x':>10s} {'PESQ':>6s} {'MMAC/s':>7s} {'ms/frm':>7s}")
    for n, r in rows.items():
        print(f"{n:28s} {r['snr_full']:8.2f} {r['snr_inband']:9.2f} {r['snr_rx_inband']:11.2f} {r['loss']:6.1f} "
              f"{r['switches']:4d} {r['trans_ratio']:10.2f} {r['pesq']:6.2f} {r['mmacs']:7.2f} {r['ms_frame']:7.3f}")
    print(f"\nAlgorithmic latency of FIR chain: {(127 - 1) / FS * 1000:.2f} ms (tx+rx)")
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        t = np.arange(len(net["bw"])) * .02
        fig, ax = plt.subplots(3, 1, figsize=(10, 8))
        ax[0].plot(t, net["bw"], label="bandwidth kbps"); ax[0].plot(t, net["jitter"], label="jitter ms", alpha=.6)
        ax[0].legend(); ax[0].set_title("Synthetic network trace")
        tt = hist["Adaptive (Kaiser+Farrow)"]; ax[1].step(t[:len(tt)], tt / 1000, where="post")
        ax[1].set_ylabel("codec tier kHz"); ax[1].set_title("Controller-selected sample rate")
        names = list(rows); ax[2].bar(names, [rows[n]["snr_inband"] for n in names]); ax[2].set_ylabel("in-band SNR dB")
        ax[2].tick_params(axis="x", labelsize=8); plt.tight_layout(); plt.savefig("results.png", dpi=110)
        print("saved results.png")
    except Exception as e: print("plot skipped:", e)
