"""Markov-chain link-quality + CPU simulator -> per-20ms-frame bandwidth, jitter, cpu."""
import numpy as np

STATES = ["good", "fair", "poor", "critical"]
BW = {0: (90, 8), 1: (45, 6), 2: (22, 4), 3: (11, 2)}      # kbps mean, std
JIT = {0: (5, 2), 1: (20, 6), 2: (50, 12), 3: (110, 20)}   # ms (correlated with bw drop)
NEED_KBPS = {8000: 12, 16000: 24, 24000: 40, 48000: 64}     # Opus-like bitrate per tier
TIERS = [8000, 16000, 24000, 48000]
FRAME_MS = 20
P = np.array([[.5, .4, .08, .02], [.3, .4, .25, .05], [.1, .35, .4, .15], [.05, .25, .4, .3]])
P /= P.sum(1, keepdims=True)


def simulate(seconds, seed=0):
    rng = np.random.default_rng(seed)
    n = int(seconds * 1000 / FRAME_MS)
    st = np.zeros(n, int); s = 0; i = 0
    while i < n:
        d = int(rng.uniform(0.5, 2.0) * 1000 / FRAME_MS)
        st[i:i + d] = s; i += d
        s = rng.choice(4, p=P[s])
    bw = np.array([max(2, rng.normal(*BW[k])) for k in st])
    jit = np.array([max(0, rng.normal(*JIT[k])) for k in st])
    cpu = np.empty(n); c = 0.8
    for k in range(n):                      # AR(1) CPU availability with random dips
        c = 0.98 * c + 0.02 * rng.uniform(0.2, 1.0) + (rng.random() < 0.003) * -0.4
        cpu[k] = np.clip(c, 0.15, 1.0)
    return dict(state=st, bw=bw, jitter=jit, cpu=cpu)


def lost(bw, jitter, tier):
    """Frame is lost if the link cannot carry the tier's bitrate or it arrives too late."""
    return NEED_KBPS[tier] > bw or jitter > 100
