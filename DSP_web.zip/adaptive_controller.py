"""Small numpy MLP (3-24-12) mapping (bandwidth, jitter, cpu) -> (codec tier, filter profile).
Trained on synthetic labels; used at run time with hysteresis (fast down-switch, slow up-switch)."""
import numpy as np
from network_sim import TIERS, NEED_KBPS

PROFILES = [(31, 5.0), (63, 7.0), (127, 9.0)]  # (taps, kaiser beta): low / mid / high cost
ACTIONS = [(t, p) for t in range(4) for p in range(3)]


def oracle(bw, jit, cpu):
    t = 0
    for k, tier in enumerate(TIERS):
        if NEED_KBPS[tier] <= 0.85 * bw:
            t = k
    p = 0 if (cpu < 0.4 or jit > 80) else 1 if cpu < 0.7 else 2
    return ACTIONS.index((t, p))


def feats(bw, jit, cpu):
    return np.stack([np.log(np.asarray(bw) / 30), np.asarray(jit) / 60 - 1, np.asarray(cpu) * 2 - 1], -1)


class Controller:
    def __init__(self, seed=0, up_dwell=10):
        self.rng = np.random.default_rng(seed); self.up_dwell = up_dwell
        self.W1 = self.rng.normal(0, .5, (3, 24)); self.b1 = np.zeros(24)
        self.W2 = self.rng.normal(0, .5, (24, 12)); self.b2 = np.zeros(12)
        self.cur = None; self.cnt = 0

    def _fwd(self, X):
        H = np.tanh(X @ self.W1 + self.b1); Z = H @ self.W2 + self.b2
        Z -= Z.max(1, keepdims=True); E = np.exp(Z)
        return H, E / E.sum(1, keepdims=True)

    def train(self, n=6000, epochs=600, lr=0.3):
        r = self.rng
        bw, jit, cpu = r.uniform(3, 100, n), r.uniform(0, 150, n), r.uniform(.1, 1, n)
        y = np.array([oracle(*a) for a in zip(bw, jit, cpu)])
        X = feats(bw, jit, cpu); Y = np.eye(12)[y]
        for _ in range(epochs):
            H, P = self._fwd(X); G = (P - Y) / n
            dW2 = H.T @ G; db2 = G.sum(0); dH = (G @ self.W2.T) * (1 - H ** 2)
            self.W1 -= lr * X.T @ dH * 10; self.b1 -= lr * dH.sum(0) * 10
            self.W2 -= lr * dW2 * 10; self.b2 -= lr * db2 * 10
        self.acc = float((self._fwd(X)[1].argmax(1) == y).mean())
        return self.acc

    def decide(self, bw, jit, cpu):
        a = int(self._fwd(feats([bw], [jit], [cpu]))[1].argmax())
        if self.cur is None: self.cur = a
        elif ACTIONS[a][0] < ACTIONS[self.cur][0]: self.cur = a; self.cnt = 0   # drop immediately
        elif ACTIONS[a][0] > ACTIONS[self.cur][0]:
            self.cnt += 1
            if self.cnt >= self.up_dwell: self.cur = a; self.cnt = 0           # raise slowly
        else: self.cur = a; self.cnt = 0
        t, p = ACTIONS[self.cur]
        return TIERS[t], *PROFILES[p]
