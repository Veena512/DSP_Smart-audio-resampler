"""Web app: upload audio -> (A) simplified-speech audio via ASR + LLM + TTS, or (B) adaptive resampling.
Run:  python app.py   then open http://127.0.0.1:5000"""
import os, re, tempfile, uuid
import numpy as np, soundfile as sf
from flask import Flask, request, jsonify, render_template, send_from_directory
from scipy.signal import resample_poly

from demo import run
from network_sim import simulate
from adaptive_controller import Controller
from polyphase_resampler import FS

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024
OUT = tempfile.mkdtemp(prefix="sr_out_")
_whisper = None
GEMINI_MODEL = None   # None = auto-pick an available Gemini flash model; or set a name like "gemini-3.8-flash"
ctrl = Controller(); ctrl.train()          # small MLP, trains in a few seconds at startup


# ---------- helpers ----------
def load_audio(path, sr=FS):
    try:
        x, s = sf.read(path, always_2d=True); x = x.mean(1)
        if s != sr: x = resample_poly(x, sr, s)
        return x.astype(np.float64)
    except Exception:                       # mp3/m4a etc.
        from faster_whisper.audio import decode_audio
        return decode_audio(path, sampling_rate=sr).astype(np.float64)


def transcribe(path):
    global _whisper
    if _whisper is None:
        from faster_whisper import WhisperModel
        _whisper = WhisperModel("base", compute_type="int8")
    audio = load_audio(path, 16000).astype(np.float32)   # decode ourselves (avoids PyAV 'metadata_errors' bug)
    segs, info = _whisper.transcribe(audio)
    return " ".join(s.text.strip() for s in segs), info.language


def gemini_candidates(client):
    """Text-capable Gemini models this key can see, flash models first, newest first."""
    names = []
    for m in client.models.list():
        if "generateContent" in (getattr(m, "supported_actions", None) or []):
            names.append(m.name.replace("models/", ""))
    bad = ("image", "tts", "live", "audio", "embedding", "robotics", "computer", "learn", "omni", "veo", "imagen")
    ok = [n for n in names if not any(x in n for x in bad)]
    pref = sorted([n for n in ok if "flash" in n], key=lambda n: ("lite" not in n, n), reverse=True)
    return list(dict.fromkeys(pref + sorted(ok)))


def gemini_generate(client, prompt):
    """Try models one by one; skip any that are retired (404) or have no free quota (429)."""
    global GEMINI_MODEL
    order = [GEMINI_MODEL] if GEMINI_MODEL else gemini_candidates(client)
    last = None
    for name in order:
        try:
            r = client.models.generate_content(model=name, contents=prompt)
            GEMINI_MODEL = name           # remember the one that worked
            return r.text.strip(), name
        except Exception as e:
            last = e
            if any(c in str(e) for c in ("429", "404", "RESOURCE_EXHAUSTED", "NOT_FOUND")):
                GEMINI_MODEL = None; continue
            raise
    raise RuntimeError(f"No Gemini model with available quota for this key. Last error: {last}")


def simplify(text, lang):
    """LLM rewrite: simple words, short sentences, same meaning. Falls back to a crude rule-based version."""
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if key:
        from google import genai
        client = genai.Client(api_key=key)
        out, name = gemini_generate(client,
            f"Rewrite the following spoken text in simple, plain language ({lang}). Use short sentences "
            "and common words. Keep every fact and the full meaning. Do not add or remove information. "
            "Return only the rewritten text.\n\n" + text)
        return out, f"Gemini ({name})"
    swaps = {"utilize": "use", "approximately": "about", "commence": "start", "purchase": "buy",
             "assist": "help", "demonstrate": "show", "additional": "more", "however": "but",
             "therefore": "so", "regarding": "about", "numerous": "many", "obtain": "get"}
    t = text
    for k, v in swaps.items(): t = re.sub(rf"\b{k}\b", v, t, flags=re.I)
    t = re.sub(r",?\s+(and|but|which|because|although)\s+", r". ", t)       # split long sentences
    t = ". ".join(s.strip().capitalize() for s in re.split(r"\.\s*", t) if s.strip()) + "."
    return t, "rule-based fallback (set GEMINI_API_KEY for real AI simplification)"


def tts(text, stem):
    wav = os.path.join(OUT, stem + ".wav")
    try:
        import pyttsx3
        e = pyttsx3.init(); e.save_to_file(text, wav); e.runAndWait()
        if os.path.exists(wav) and os.path.getsize(wav) > 1000: return stem + ".wav"
    except Exception: pass
    from gtts import gTTS
    gTTS(text).save(os.path.join(OUT, stem + ".mp3")); return stem + ".mp3"


# ---------- routes ----------
@app.errorhandler(Exception)
def on_error(e):
    """Always answer with JSON (never an HTML error page) and print the traceback in the terminal."""
    import traceback
    from werkzeug.exceptions import HTTPException
    traceback.print_exc()
    code = e.code if isinstance(e, HTTPException) else 500
    msg = "File too large (limit 50 MB)" if code == 413 else f"{type(e).__name__}: {e}"
    return jsonify(error=msg), code


@app.route("/")
def index(): return render_template("index.html")


@app.route("/audio/<name>")
def audio(name): return send_from_directory(OUT, name)


@app.route("/process", methods=["POST"])
def process():
    f = request.files.get("file"); mode = request.form.get("mode", "simplify")
    if not f: return jsonify(error="No file uploaded"), 400
    stem = uuid.uuid4().hex[:10]
    src = os.path.join(OUT, stem + "_in" + os.path.splitext(f.filename)[1]); f.save(src)
    try:
        if mode == "resample":
            x = load_audio(src)[: FS * 120]
            net = simulate(len(x) / FS + 1, seed=int(request.form.get("seed", 0)))
            y, tiers, lost, macs, ms = run(x, net, "adaptive", ctrl)
            y = y[126:]; y = y / (np.abs(y).max() + 1e-9) * 0.9
            sf.write(os.path.join(OUT, stem + ".wav"), y, FS)
            rates = {int(t): int((tiers == t).sum()) for t in np.unique(tiers)}
            info = (f"Frames per codec rate (Hz): {rates}. Frames lost on simulated network: "
                    f"{100 * lost.mean():.1f}%. Rate switches: {int((np.diff(tiers) != 0).sum())}.")
            return jsonify(audio_url=f"/audio/{stem}.wav", info=info)
        text, lang = transcribe(src)
        if not text.strip(): return jsonify(error="No speech detected"), 400
        simple, how = simplify(text, lang)
        name = tts(simple, stem)
        return jsonify(audio_url=f"/audio/{name}", original=text, simplified=simple, info=f"Simplified by: {how}")
    except Exception as e:
        return jsonify(error=f"{type(e).__name__}: {e}"), 500


if __name__ == "__main__":
    app.run(debug=False)
